"""Assemble G2 submission from actual audit JSON and CSV."""
import json
from pathlib import Path
import pandas as pd


def main():
    root=Path('results/p3/fair01')
    a=json.loads((root/'audit.json').read_text())
    original=json.loads(Path('results/p3/main01/audit.json').read_text())
    findings=json.loads((root/'findings.json').read_text())
    replay=json.loads((root/'pilot_reproduction.json').read_text())
    assert a['evaluations']==324 and a['configurations']==27
    reductions=pd.read_csv(root/'reduction_statistics.csv')
    lines=['|评价|基线|均值降低%|最小%|最大%|正增益配置数|', '|---|---|---:|---:|---:|---:|']
    for row in reductions.itertuples():
        lines.append(f'|{row.evaluation}|{row.baseline}|{row.mean_pct:.4f}|{row.min_pct:.4f}|{row.max_pct:.4f}|{row.positive_count}/27|')
    table='\n'.join(lines)
    body=f'''# G2 人工审查：正式实验与可使用的结论候选

**状态：WAITING_USER_G2；未批准。** 2026-10-26（Asia/Shanghai）。P3/P4计算及复核已完成；没有进入P5最终论文。

## 1. G1批准与模型

用户2026-10-26明确回复“批准 G1，按路线 A 及所列范围继续”；五项范围见APPROVAL_LOG.md。v2数学模型未变，有限时域、非零和、K槽开环，合成图，来源出边隔离/本地恢复共享瞬时容量。新增公平评价层的原因与过程见reports/P3_execution_notes.md。

## 2. 实验及复现入口

27配置：n=6,K=6,T=10；3场景×3种子×3预算，六方法、fixed/adaptive两评价，共324条成本记录。原候选结果results/p3/main01；主公平比较results/p3/fair01。无失败配置被删除或替换。每配置包含参数、边表、原始响应初末控制和退出码、控制/状态轨迹、逐槽预算和12/24/48积分细化。

```powershell
python -m pytest -q
python -m src.experiments --config configs/base.yaml --output results/p3/reproduce_main
python -m src.fair_evaluation --source results/p3/reproduce_main --output results/p3/reproduce_fair
python -m src.audit_p3 --root results/p3/reproduce_fair
python -m src.summarize_p3 --root results/p3/reproduce_fair
```

audit的pilot复现对照为同级pilot01/pilot02。独立重新优化覆盖pilot；324条全批次检查覆盖保存控制重积分，不冒称全批次独立重新优化。数值环境Python3.11.7、NumPy1.26.4、SciPy1.11.4、pytest7.4.0；pytest仍低于原声明>=8，差异不隐去。

## 3. 数值质量

|项目|实际结果|边界|
|---|---:|---|
|测试|15通过|包括消融、同策略对gap与复现|
|正式配置/评价|{a['configurations']} / {a['evaluations']}|限定预登记合成参数|
|原交替目标通过|{original['game_targets_pass']}/{original['game_count']}|1%工程目标|
|完整攻击评价后目标通过|{a['game_targets_pass']}/{a['game_count']}|不同于全局证书|
|完整攻击评价后质量通过|{a['game_quality_pass']}/{a['game_count']}|多起点成功及局部残差|
|最大相对观测改善|{a['relative_gap_max']:.9g}|两方最大值；未知全局gap|
|最大逐槽违规|{a['violation_max']:.4g}|阈值1e-10|
|12对48子步目标最大误差|{a['integration_max_error']:.4g}|阈值1e-5，非K精化|
|重新积分最大差|{a['reintegration_max_error']:.4g}|从CSV控制恢复|
|目标分解最大误差|{a['decomposition_max_error']:.4g}|各分项求和|
|全部状态在域内|{a['domain_pass']}|仅实测轨迹|
|全部已审计起点成功|{a['all_optimizers_success']}|退出状态不是全局最优|
|选中响应最大投影残差|{a['selected_response_max_residual']:.4g}|局部必要性诊断|
|各起点最大投影残差|{a['all_start_max_residual']:.4g}|完整记录保留|
|多起点最大目标差|{a['multistart_max_objective_spread']:.4g}|不是非凸全域保证|
|细积分成本排序变化|{a['ranking_changes']}|所有配置/评价|
|pilot复现最大差|{replay['max_abs_difference']:.4g}|控制与数值汇总，排除时间|

证据：fair01/audit.json、reintegration_audit.csv、optimizer_audit.csv、ranking_audit.csv、pilot_reproduction.json；main01保存原交替全过程。fair01攻击侧近零偏离由同一次完整局部响应构造，不能当独立全局认证。

## 4. 公平性与效果大小

同配置共享网络、入口、x0、时域、成本和预算；跨场景同种子beta核对结果：{findings['same_graph_within_seed']}。fixed入口各0.4，所有方法共用。启发式隔离/恢复50:50，不调优；两种单控制基线均重新优化。adaptive对每个最终防御完整重求攻击响应；主比较不使用仍带阻尼的候选攻击。三种优化方法最终防御来自交替过程，故fixed/adaptive差异同时涉及防御与攻击，不能作纯攻击效应因果解释。

下表为逐配置配对的100×(基线成本−联合成本)/基线成本，再汇总27配置。不是总体推断或显著性检验；逐种子SD、原始配对值均保存。

{table}

证据：fair01/paired_comparisons.csv、reduction_statistics.csv、seed_statistics.csv；图figures/p3/paired_ablation.pdf。

## 5. 可供G2批准的有限结论

1. **可计算性**：上述合成K槽任务可运行，81个优化方法/配置的诊断通过数以第3节为准。建议用“交替局部响应候选策略及完整攻击响应评价”；不使用“已求得连续反馈Nash”。
2. **有限增益**：联合控制相对各基线的成本差仅允许引用第4节完整范围，并同时报告相对仅恢复的微小增益配置；不得只摘最大百分比。
3. **容量边界**：Joint/adaptive各预算绑定槽数统计为 `{json.dumps(findings['joint_binding_by_B'],ensure_ascii=False)}`。保留P2全槽松弛历史，不能反向抹除该负结果。证据：summary.csv与各budgets.csv；图capacity.pdf。
4. **业务代价敏感性**：C相对B的高传播节点平均隔离变化范围[{findings['business_change_min']:.6g}, {findings['business_change_max']:.6g}]，9个配对中{findings['business_decreased_count']}个明显降低（描述阈值1e-6）。只支持本参数下控制变化。证据business_paired.csv；图business.pdf。

这些是待用户确认的结果候选，不是已经获准写入最终摘要/结论的文本。

## 6. 未成立的强主张与负结果

- 没有全局gap上界、Nash存在唯一性证明、连续时间反馈解或K槽精化收敛证据。RK4精化只检验给定控制的积分。
- 工程目标允许较早停止，不能据此宣称防御策略已经稳定收敛或展示了充分的攻击适应机制。
- 相对最强基线的增益可能很小，不能用相对均分启发式的较大差替代增量价值论证。
- 明确反例：seed=33、business_cost、B=0.6、adaptive_attack，Joint成本12.441140，Recovery-only成本12.439787；联合策略高约0.010878%。这是保存候选策略的实际成本反例，不能宣称始终优于仅恢复；也不据此证明全局最优联合控制必然较差。
- 高q移动同时改变入口和初始受损的位置关系；A/B差异不能全部归因于价值—传播错位。
- 事后描述的高传播隔离与高价值恢复排序符号变化出现在{findings['exploratory_priority_switch_count']}/27配置；这不是预登记检验，更不是普适阈值或优先级切换定理。原表mechanism_diagnostics.csv完整保留。
- 三种子不是生产云实测；拓扑名modular未验证社区结构。没有参数标定、现实攻击路径验证或部署实验。广泛近邻查新及增量贡献评价仍未关闭。

## 7. 方法标签建议与请求

保留路线A的探索定位；建议论文采用“分段开环交替局部响应与对抗评价”，不请求批准“严格Nash/连续反馈Nash”，也不因达到1%自动使用“受限近似Nash”。若用户认为现有局部证据不足，应补更强求解诊断或在G2决定路线B，不自行替换研究路线。

请明确决定：是否接受上述有限数值结论及局限，并允许进入P5论文合稿？可回复：**批准 G2，仅采用上述已核实的有限结论，使用交替局部响应表述**；或 **G2 不通过：……**。

此处暂停依据项目AGENTS.md：“G1、G2为强制暂停点”。G1授权研究执行，不授权代替用户批准G2。

## 审批区

- 用户G2回复原文：尚未收到。
- G2状态：PENDING。
- 未发布包含上述结果的最终摘要、结论或“已完成”论文初稿。
'''
    Path('reviews/G2_submission.md').write_text(body,encoding='utf-8')
    Path('reports/P3_P4_verification.md').write_text('# P3/P4审计汇总\n\n'+body.split('## 3. 数值质量')[1].split('## 4.')[0],encoding='utf-8')


if __name__=='__main__':main()
